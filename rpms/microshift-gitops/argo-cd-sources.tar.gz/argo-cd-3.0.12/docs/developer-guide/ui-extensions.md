The contents of this document have been moved to the
[extensions guide](./extensions/ui-extensions.md)
